package com.example.amang.guesture;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.view.MotionEvent;
import android.view.GestureDetector;
import android.support.v4.view.GestureDetectorCompat;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener,GestureDetector.OnDoubleTapListener{

    private TextView text;
    private GestureDetectorCompat detector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text = (TextView)findViewById(R.id.tv1);
        this.detector = new GestureDetectorCompat(this,this);
        detector.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.detector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(MotionEvent motionEvent) {
        text.setText("Single Tap Confirmed");
        return true;
    }

    @Override
    public boolean onDoubleTap(MotionEvent motionEvent) {
        text.setText("Double Tap Confirmed");
        return true;
    }

    @Override
    public boolean onDoubleTapEvent(MotionEvent motionEvent) {
        text.setText("Double Tap Event Confirmed");
        return true;
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        text.setText("on Down Confirmed");
        return true;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {
        text.setText("Press Confirmed");

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        text.setText("Single Tap up Confirmed");
        return true;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        text.setText("Scroll Confirmed");
        return true;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {
        text.setText("Long press Confirmed");
    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        text.setText("Fling Confirmed");
        return true;

    }
}
