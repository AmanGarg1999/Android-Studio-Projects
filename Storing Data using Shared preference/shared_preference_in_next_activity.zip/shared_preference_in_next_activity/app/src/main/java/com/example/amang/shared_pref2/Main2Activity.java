package com.example.amang.shared_pref2;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView txt1,txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lay2);
        txt1 = (TextView)findViewById(R.id.tv1);
        txt2 = (TextView)findViewById(R.id.tv2);
        final String prefString = "User_info";
        SharedPreferences sh = getSharedPreferences("User info", Context.MODE_PRIVATE);
        String user = sh.getString("user","Empty");
        String email =  sh.getString("email","Empty");
        txt1.setText("User =     " + user);
        txt2.setText("email =    " + email);

    }
}
