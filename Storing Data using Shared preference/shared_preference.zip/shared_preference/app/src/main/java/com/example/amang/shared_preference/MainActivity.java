package com.example.amang.shared_preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2;
    TextView txt1,txt2;
    Button b1,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_layout);
        ed1 =(EditText)findViewById(R.id.et1);
        ed2 =(EditText)findViewById(R.id.et2);
        b1 = (Button)findViewById(R.id.bt1);
        b2 = (Button)findViewById(R.id.bt2);
        txt1 = (TextView)findViewById(R.id.tv1);
        txt2 = (TextView)findViewById(R.id.tv2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh = getSharedPreferences("User info", Context.MODE_PRIVATE);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("user",ed1.getText().toString());
                ed.putString("email",ed2.getText().toString());
                ed.apply();
                ed.commit();
                Toast.makeText(getApplicationContext(),"Saving data",Toast.LENGTH_SHORT).show();

            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh = getSharedPreferences("User info", Context.MODE_PRIVATE);
                String user = sh.getString("user","Empty");
                String email =  sh.getString("email","Empty");
                txt1.setText("User = " + user );
                txt2.setText("email = " + email);
                Toast.makeText(getApplicationContext(),"Displaying data",Toast.LENGTH_SHORT).show();

            }
        });
    }

}
