package com.example.amang.madclass1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    EditText e;
    TextView t;
    Button b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);

        e=(EditText) findViewById(R.id.ED1);
        t = (TextView) findViewById(R.id.txt1);
        b = (Button) findViewById(R.id.B1);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s = e.getText().toString();
                s = s.toUpperCase();
                char as[] = s.toCharArray();
                Arrays.sort(as);
                String s1 = new String(as);
                Toast.makeText(getApplicationContext(),"Sorting",Toast.LENGTH_SHORT).show();
                t.setText(s1);
            }
        });

    }
}
