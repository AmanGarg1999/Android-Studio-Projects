package com.example.amang.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.security.spec.ECField;

public class MainActivity extends AppCompatActivity {
    EditText edittext;
    Button bt1,bt2;
    TextView txt;
    String f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext =(EditText)findViewById(R.id.et1);
        bt1 = (Button)findViewById(R.id.b1);
        bt2 = (Button)findViewById(R.id.b2);
        txt =(TextView)findViewById(R.id.tv1);
        f = "d.txt";

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                writeData(f,edittext.getText().toString());
                Toast.makeText(getApplicationContext(),"Writing Data to File",Toast.LENGTH_SHORT).show();
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               readData(f);
                Toast.makeText(getApplicationContext(),"Reading Data from File",Toast.LENGTH_SHORT).show();
                }
        });
    }


    public void writeData(String f,String d)
    {
        try{
            FileOutputStream fw = openFileOutput(f,MODE_PRIVATE);
            d = d +"\n";
            fw.write(d.getBytes());
            fw.close();
            }
        catch(Exception e)
            {
                e.printStackTrace();
            }
    }
    public void readData(String f)
    {
        try{
            FileInputStream fin = openFileInput(f);
            BufferedReader br = new BufferedReader(new InputStreamReader(fin));
            String d = br.readLine();
            txt.setText(d);
            br.close();

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

