package com.example.amang.app1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    EditText edittext;
    InputStream is;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittext = (EditText)findViewById(R.id.et1);
        is = getResources().openRawResource(R.raw.book);
        button = (Button)findViewById(R.id.b1);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String edText = edittext.getText().toString();
                BufferedReader Reader = new BufferedReader(new InputStreamReader(is));
                String line;
                try{
                    while((line = Reader.readLine() )!= null){
                        String arr[] = line.split(",");
                        if(arr[0].equalsIgnoreCase(edText)){
                            Intent in = new Intent(getApplicationContext(),Main2Activity.class);
                            in.putExtra("word",arr[0]);
                            in.putExtra("Synnonym",arr[1]);
                            startActivity(in);
                            Toast.makeText(getApplicationContext(),"Finding Text",Toast.LENGTH_SHORT).show();
                            break;
                        }
                    }
                } catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }

}
